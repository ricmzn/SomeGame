Sky cube created in blender, starry texture generated with Spacescape - http://sourceforge.net/projects/spacescape/
